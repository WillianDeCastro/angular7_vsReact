function carregar() {

  var request = new XMLHttpRequest()

  // Open a new connection, using the GET request on the URL endpoint
  request.open('GET', 'https://localhost:44397/api/values', true)

  request.onload = function () {
    // Begin accessing JSON data here

    var data = JSON.parse(this.response)
    //console.log(data);

    const elemento = document.getElementById('resultado');
    data.forEach(retorno => {

      var li = document.createElement("li");
      li.innerHTML = retorno;
      elemento.appendChild(li);
 
    })

  }
  // Send request
  request.send()
}
