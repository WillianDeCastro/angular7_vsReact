﻿using System.Collections.Generic;

namespace ApiTeste
{
    public class Bank
    {

        public List<string> ObterValores()
        {
            var lista = new List<string>();

            for (int i = 0; i < 50000; i++)
            {
                lista.Add("valor" + i);
            }

            return lista;
        }
    }
}
