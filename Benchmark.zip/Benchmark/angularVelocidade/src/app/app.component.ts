import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'angularVelocidade';

  items: Array<any>;

  constructor(public httpCli: HttpClient) {


  }

  public Informa() {

    this.httpCli.get('https://localhost:44397/api/values').subscribe(
      (ret: any) => {

        this.items = ret;
      }
    )

  }
}
